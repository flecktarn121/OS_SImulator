All the exercises are finished and, apparently, are working fine.
Some problems may be present, due to issues from previous versions
not yet solved.
