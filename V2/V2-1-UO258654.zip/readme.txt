Exercise 1 is partially completed, and 2 should be finished, but the program enters in an infinite loop.
