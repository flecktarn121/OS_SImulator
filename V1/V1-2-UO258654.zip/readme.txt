The 12 exercise has been implemented (not tested), except from the check of the process type (as the exercise 11 was not finished)
The log will be empty, as I did not have time to execute them.
