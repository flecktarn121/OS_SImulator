All the exercises from 0 to 7 should have been completed.
