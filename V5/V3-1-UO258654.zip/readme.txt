Due to the time spent in the installation of the local enviroment, only exercise 1 nhas been done.
