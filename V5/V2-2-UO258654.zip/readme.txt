All exercises should be from 0 to 5. 
In 6, a and b have been done, but the compilation fails.
