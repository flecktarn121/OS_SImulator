All the exercises should be done.
